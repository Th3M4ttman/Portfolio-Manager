###########################
## set up

# set up visualization output directory
vis_dir <- str_c(root_dir, "Visualizations/")


###########################
## visualization templates

# univariate statistical plots
#ggplot(df, aes(x=x, color = x)) + geom_histogram(aes(y=..density..)) + geom_density() + geom_rug(data=df,aes(x=x))
#ggplot(df, aes(x, y, color = y)) + geom_boxplot() + coord_flip() + geom_rug(data=df)

# multivariate statistical plots

#############################
## output visualizations


#############################
## save workspace and history
save.image(file = workspace_path)
savehistory(file = history_path)