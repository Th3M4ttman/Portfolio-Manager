package deltadak;

/**
 * Default Hello class.
 */
public class HelloWorld {

    /**
     * Default main method.
     * @param args I forgot what these were about.
     */
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }

    /**
     * Find out what 1+1 is.
     * @return 1+1
     */
    public int calculate() {
       return 1+1;
    }
}
