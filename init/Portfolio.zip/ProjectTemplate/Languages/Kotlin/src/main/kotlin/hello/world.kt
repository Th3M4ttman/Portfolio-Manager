package hello

fun main() {
    println("hello world!")
}
