package hello

import kotlin.test.Test
import kotlin.test.assertEquals

internal class WorldTest {

    @Test
    fun `2 + 3 equals 5`() {
        assertEquals(5, 2 + 3)
    }

}
